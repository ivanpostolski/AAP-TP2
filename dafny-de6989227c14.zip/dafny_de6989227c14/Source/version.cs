using System.Reflection;
// Version 1.9.5, year 2013+2 month 05 day 11
[assembly: AssemblyVersion("1.9.5.20511")]
[assembly: AssemblyFileVersion("1.9.5.20511")]
