#Notice

The [Dafny] syntax module for [Vim] that is located within directory will no longer be updated and has been superseded by the [vim-loves-dafny] plugin.

[Dafny]: http://dafny.codeplex.com
[Vim]: http://www.vim.org
[vim-loves-dafny]: https://github.com/mlr-msft/vim-loves-dafny
